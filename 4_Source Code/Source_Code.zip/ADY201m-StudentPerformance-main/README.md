# Student Performance Factors Analysis (SQL & Python)

Dự án xây dựng quy trình Khoa học Dữ liệu 10 bước (Data Science Methodology) kết hợp SQL (SQLite) và Python để truy xuất, làm sạch, khám phá dữ liệu (EDA), kiểm định giả thuyết thống kê (ANOVA/T-test) và xây dựng mô hình hồi quy tuyến tính trên bộ dữ liệu `StudentPerformanceFactors.csv` (6,607 bản ghi, 16 cột).

## Cấu trúc dự án

- `PhanTich_10Buoc_SQL_Python.ipynb`: Notebook thực hiện trọn vẹn 10 bước Data Science Methodology bằng SQL và Python.
- `StudentPerformanceAnalysis.ipynb`: Notebook phân tích khám phá dữ liệu (EDA), IQR Outliers, kiểm định ANOVA/T-test và Hồi quy tuyến tính.
- `TruyVan_LamSach_PhanTich.sql`: 14 câu lệnh truy vấn, làm sạch và phân tích dữ liệu chạy độc lập trên SQLite.
- `student_analysis.db`: Cơ sở dữ liệu SQLite chứa bảng gốc `raw_students` và các bảng đã làm sạch `students_clean_sql`, `students_clean_python`.
- `data_csv/`: Thư mục chứa dữ liệu gốc và các bảng dữ liệu đầu ra sau khi làm sạch.
